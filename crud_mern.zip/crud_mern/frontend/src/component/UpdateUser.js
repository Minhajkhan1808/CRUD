
import React, { useEffect, useState } from 'react'
import axios from 'axios';
import { useNavigate,useParams } from 'react-router-dom';

const UpdateUser =()=> {
    const[name,setName]= useState("")
    const[email,setEmail]= useState("")
    const[gender,setGender]= useState("")
    const navigate = useNavigate();
    const{id} = useParams();

    useEffect(()=>{
      getUserById();
    });
    
    const getUserById = async ()=>{
      const response = await axios.get(`http://localhost:5000/users/${id}`);
      setName(response.data.name);
      setEmail(response.data.email);
      setGender(response.data.gender);
  
     }
    const updateUser= async (e)=>{
        e.preventDefault();
      try {
           await axios.patch(`http://localhost:5000/users/${id}`,{
        name,email,gender
       });
        navigate("/");
      } catch (error) {
        console.log(error);
      }
    };

  return (
    <div className="d-flex vh-100 bg-primary justify-content-center align-items-center">
    <div className="w-50 bg-white rounded p-3">
        <form onSubmit={updateUser}>
            <h2>Update</h2>
            <div className='mb-2'>
                <label htmlfor="">Name</label>
                <input type='text' placeholder='enter your name' className='form-control'
                onChange={(e)=> setName(e.target.value)}/>
            </div>
            <div className='mb-2'>
                <label htmlfor="">Email</label>
                <input type='text' placeholder='enter your email' className='form-control'
                onChange={(e)=> setEmail(e.target.value)}/>
            </div>
            <div className='mb-2'>
                <label htmlfor="">Gender </label>
                <br/>
               <select className='w-50 bg-white rounded p-1' value={gender} onChange={(e)=> setGender(e.target.value)}>
                <option value='Male'>Male</option>
                <option value='Female'>Female</option>
               </select>
            </div>
            <button  type='submit' className='btn btn-success'>Update</button>
        </form>


      </div>
    </div>
  )
}

export default UpdateUser


